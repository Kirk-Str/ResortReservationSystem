# ResortReservationSystem


*****Issue Note*****

System throws error when running on Xampp ver above 7.1
It will be resolved by using anything 7.1 or below