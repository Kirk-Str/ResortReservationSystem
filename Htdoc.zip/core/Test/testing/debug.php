<?php 

        //require 'core/init.php';
        echo Email::RoomReservationConfirmed('dd');
        //mail('effersonjack@gmail.com', 'Testing Raw mail', 'Body content', 'From: noreply@happyholiday.ezyro.com');
        //echo Email::RoomReservationConfirmed('effersonjack@gmail.com', '2017-01-01', '2017-05-01', 2, 1, 'test', 2123, 123);

        // $core = new Dwoo\Core();

        // // Load a template file, this is reusable if you want to render multiple times the same template with different data
        // $generalEmailTemplate = new Dwoo\Template\File('./layouts/template/_emailTemplateGeneral.tpl');
        // $mainContentEmailTemplate = new Dwoo\Template\File('./layouts/template/_emailTemplateMainContentReservation.tpl');
        // $subContentEmailTemplate = new Dwoo\Template\File('./layouts/template/_emailTemplateSubContentReservation.tpl');

        // $mainPageData = new Dwoo\Data();
        // $mainContentPageData = new Dwoo\Data();
        // $SubContentPageData = new Dwoo\Data();


        // $guestName = '';
        // $reservationId = '';
        // $checkInDate = '';
        // $checkOutDate = '';
        // $noNightsStay = '';
        // $adults = '';
        // $children = '';
        // $roomType = '';
        // $totalAmount = '';
        // $paidAmount = '';
        // $balanceAmount = '';
        // $roomRate = '';

        // $mainContentPageData->assign('guest_name', $guestName);
        // $mainContentPageData->assign('reservation_id', $reservationId);
        // $mainContentPageData->assign('check_in_date', $checkInDate);
        // $mainContentPageData->assign('check_out_date', $checkOutDate);
        // $mainContentPageData->assign('no_nights_stay', $noNightsStay);
        // $mainContentPageData->assign('adults', $adults);
        // $mainContentPageData->assign('children', $children);
        // $mainContentPageData->assign('room_type', $roomType);
        // $mainContentPageData->assign('total_amount', $totalAmount);
        // $mainContentPageData->assign('paid_amount', $paidAmount);
        // $mainContentPageData->assign('balance_amount', $balanceAmount);
        // $mainContentPageData->assign('room_rate', $roomRate);

        // $summary = 'Summary';
        
        // $mainContent = $core->get($mainContentEmailTemplate, $mainContentPageData);
         
        // $subContent = $core->get($subContentEmailTemplate);
       
        // $mainPageData->assign('summary', $summary);
        // $mainPageData->assign('main_content', $mainContent);
        // $mainPageData->assign('sub_content', $subContent);

        // echo $core->get($generalEmailTemplate, $mainPageData);
       
   ?>

