$(function(){

    $('#reservation-list tbody').on( 'click', 'tr', function () {
        
    } );

});