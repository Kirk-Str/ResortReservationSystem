<?php

class PageTemplate{
    public $title;
    public $header;
    public $content;
    public $footer;
    public $script;
}

?>